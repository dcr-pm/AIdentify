import React, { useState } from "react";
// Removed framer-motion since the hero heading has been removed
// Icons from lucide-react (available globally when using shadcn/ui)
import {
  UploadCloud,
  FileText,
  Image as ImageIcon,
  AudioLines,
  Link as LinkIcon,
  Clock,
  Trash,
  History as HistoryIcon,
  CheckCircle,
  XCircle,
  Info,
} from "lucide-react";

/**
 * AdHumanityScanner
 *
 * A sleek single‑file React component showcasing a privacy‑first multimodal analyser.
 * The layout splits the screen into a left input panel and a right output panel.
 * Users can paste text, upload files, or drop video links for sentiment analysis.
 *
 * Tailwind CSS drives the appearance and micro‑interactions.
 * Replace the stubbed analyse functions (`fakeAnalyse*`) with your own endpoints.
 */
export default function AdHumanityScanner() {
  // Mode selection: one of "text", "image", "audio", "video"
  const [mode, setMode] = useState<"text" | "image" | "audio" | "video">(
    "text"
  );
  const [inputValue, setInputValue] = useState<string>("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [results, setResults] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);

  /**
   * Handler for the file input change. Stores the selected file.
   */
  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      // Reset the text input when a file is chosen
      setInputValue("");
    }
  }

  /**
   * Clears all user inputs and analysis results.
   */
  function handleClear() {
    setInputValue("");
    setSelectedFile(null);
    setResults(null);
  }

  /**
   * Invoked when the user clicks the Analyse button. Depending on the mode,
   * this calls a stubbed function that returns fake analysis output. Replace
   * these functions with real HTTP calls to your backend.
   */
  async function handleAnalyse() {
    let output;
    if (mode === "text") {
      output = await fakeAnalyseText(inputValue);
    } else if (mode === "image") {
      output = await fakeAnalyseImage(selectedFile);
    } else if (mode === "audio") {
      output = await fakeAnalyseAudio(selectedFile);
    } else {
      // video
      output = await fakeAnalyseVideo(inputValue);
    }
    setResults(output);
    // Record the history of analyses
    const entry = {
      id: Date.now(),
      mode,
      input: selectedFile?.name || inputValue,
      timestamp: new Date().toLocaleString(),
      result: output,
    };
    setHistory((prev) => [entry, ...prev.slice(0, 7)]); // keep last 8
  }

  // ---------------------------------------------------------------------------
  // The following functions simulate network requests and return dummy data.
  // Replace these with your own API calls.
  async function fakeAnalyseText(text: string) {
    await sleep(600);
    return {
      verdict: "Likely authentic",
      confidence: 0.86,
      evidence: [
        "Readability metrics within normal bounds",
        "No unusual idioms detected",
      ],
      stakeholders: [
        {
          name: "Speaker A",
          sentiment: "Neutral",
          point: "Asks for clarity on an issue",
        },
      ],
    };
  }
  async function fakeAnalyseImage(file: File | null) {
    await sleep(800);
    return {
      verdict: "Likely manipulated",
      confidence: 0.72,
      evidence: ["ELA highlights inconsistencies", "Noise levels vary significantly"],
      stakeholders: [],
    };
  }
  async function fakeAnalyseAudio(file: File | null) {
    await sleep(1000);
    return {
      verdict: "Likely authentic",
      confidence: 0.91,
      evidence: ["Smooth prosody", "No voiceprint mismatches"],
      stakeholders: [],
    };
  }
  async function fakeAnalyseVideo(url: string) {
    await sleep(1200);
    return {
      verdict: "Likely deepfake",
      confidence: 0.64,
      evidence: ["Lip sync mismatch", "Temporal jitter across frames"],
      stakeholders: [],
    };
  }
  function sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // ---------------------------------------------------------------------------
  return (
    <div className="min-h-screen bg-[#010a11] text-white font-sans">
      {/* Header / Branding */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-[#0e2535]">
        <div className="flex items-center gap-3">
          <div className="bg-[#06e5cf] rounded-full w-8 h-8 flex items-center justify-center shadow-lg">
            {/* Replace with your actual logo SVG */}
            <UploadCloud className="text-[#010a11] w-5 h-5" />
          </div>
          {/* Brand name removed as per user request */}
        </div>
        <div className="flex items-center gap-4 text-sm opacity-80">
          <span className="flex items-center gap-2"><Info className="w-4 h-4 text-[#06e5cf]" /> Privacy‑first</span>
          <span className="flex items-center gap-2"><Info className="w-4 h-4 text-[#06e5cf]" /> Multi‑modal</span>
          <span className="flex items-center gap-2"><Info className="w-4 h-4 text-[#06e5cf]" /> Evidence‑based</span>
        </div>
      </header>

      {/* The hero tagline has been removed as per user request */}

      {/* Main content */}
      <main className="px-6 pb-10 grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input panel */}
        <section className="bg-[#02101d] rounded-2xl p-6 shadow-xl flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Input</h3>
            <div className="flex gap-1 rounded-lg bg-[#031727] p-1">
              {[
                { key: "text", label: "Text", icon: FileText },
                { key: "image", label: "Image", icon: ImageIcon },
                { key: "audio", label: "Audio", icon: AudioLines },
                { key: "video", label: "Video", icon: LinkIcon },
              ].map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => {
                    setMode(key as any);
                    // Reset previous selections when mode changes
                    setInputValue("");
                    setSelectedFile(null);
                    setResults(null);
                  }}
                  className={`flex items-center gap-2 px-3 py-1 rounded-md text-sm hover:bg-[#032437] transition-colors ${
                    mode === key ? "bg-[#06e5cf] text-[#010a11]" : "text-gray-300"
                  }`}
                >
                  <Icon className="w-4 h-4" /> {label}
                </button>
              ))}
            </div>
          </div>
          {/* Mode specific input */}
          <div className="flex-1">
            {mode === "text" && (
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Enter or paste text here…"
                className="w-full h-56 bg-[#031727] text-gray-100 p-4 rounded-lg border border-[#053b55] focus:outline-none focus:ring-2 focus:ring-[#06e5cf] placeholder-gray-500"
              />
            )}
            {mode === "image" && (
              <div className="flex flex-col items-center justify-center h-56 bg-[#031727] rounded-lg border border-dashed border-[#053b55] text-gray-400">
                <p className="mb-2">Drop an image here or click to browse</p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="cursor-pointer opacity-0 absolute inset-0 w-full h-full"
                />
                {selectedFile && (
                  <p className="mt-4 text-sm text-[#06e5cf]">{selectedFile.name}</p>
                )}
              </div>
            )}
            {mode === "audio" && (
              <div className="flex flex-col items-center justify-center h-56 bg-[#031727] rounded-lg border border-dashed border-[#053b55] text-gray-400">
                <p className="mb-2">Drop an audio file here or click to browse</p>
                <input
                  type="file"
                  accept="audio/*"
                  onChange={handleFileChange}
                  className="cursor-pointer opacity-0 absolute inset-0 w-full h-full"
                />
                {selectedFile && (
                  <p className="mt-4 text-sm text-[#06e5cf]">{selectedFile.name}</p>
                )}
              </div>
            )}
            {mode === "video" && (
              <input
                type="url"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Paste a YouTube / TikTok / Instagram link…"
                className="w-full h-12 bg-[#031727] text-gray-100 p-3 rounded-lg border border-[#053b55] focus:outline-none focus:ring-2 focus:ring-[#06e5cf] placeholder-gray-500"
              />
            )}
          </div>
          {/* Action buttons */}
          <div className="flex justify-end gap-4">
            <button
              onClick={handleClear}
              className="flex items-center gap-2 px-4 py-2 bg-transparent border border-[#053b55] text-gray-300 rounded-md hover:bg-[#032437] transition-colors"
            >
              <Trash className="w-4 h-4" /> Clear
            </button>
            <button
              onClick={handleAnalyse}
              disabled={mode === "text" ? !inputValue.trim() : mode === "video" ? !inputValue.trim() : !selectedFile}
              className="flex items-center gap-2 px-4 py-2 bg-[#06e5cf] text-[#010a11] rounded-md font-semibold hover:bg-[#04c3ae] disabled:bg-[#024e4a] disabled:cursor-not-allowed transition-colors"
            >
              <CheckCircle className="w-4 h-4" /> Analyse
            </button>
          </div>
        </section>

        {/* Output panel */}
        <section className="bg-[#02101d] rounded-2xl p-6 shadow-xl flex flex-col gap-6">
          <h3 className="text-xl font-semibold">Output</h3>
          {results ? (
            <div className="flex-1 overflow-auto">
              <div className="space-y-4">
                <div className="border border-[#053b55] rounded-lg p-4 bg-[#031727]">
                  <p className="text-sm uppercase text-gray-400 mb-1">Verdict</p>
                  <p className="text-lg font-bold text-[#06e5cf] flex items-center gap-2">
                    {results.verdict}
                    {results.verdict.toLowerCase().includes("authentic") ? (
                      <CheckCircle className="w-5 h-5 text-[#06e5cf]" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-500" />
                    )}
                  </p>
                </div>
                <div className="border border-[#053b55] rounded-lg p-4 bg-[#031727]">
                  <p className="text-sm uppercase text-gray-400 mb-1">Confidence</p>
                  <p className="text-lg font-bold text-[#06e5cf]">{(results.confidence * 100).toFixed(1)}%</p>
                </div>
                {results.evidence && results.evidence.length > 0 && (
                  <div className="border border-[#053b55] rounded-lg p-4 bg-[#031727]">
                    <p className="text-sm uppercase text-gray-400 mb-2">Evidence</p>
                    <ul className="list-disc list-inside text-gray-200 space-y-1">
                      {results.evidence.map((item: string, idx: number) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {results.stakeholders && results.stakeholders.length > 0 && (
                  <div className="border border-[#053b55] rounded-lg p-4 bg-[#031727]">
                    <p className="text-sm uppercase text-gray-400 mb-2">Stakeholder Summary</p>
                    <div className="space-y-2">
                      {results.stakeholders.map((person: any, idx: number) => (
                        <div key={idx} className="p-3 border border-[#053b55] rounded-md bg-[#041f2f]">
                          <p className="text-md font-semibold text-[#06e5cf]">{person.name}</p>
                          <p className="text-sm text-gray-300">Sentiment: {person.sentiment}</p>
                          <p className="text-sm text-gray-300">Point: {person.point}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {/* Export buttons */}
                <div className="flex gap-4">
                  <button className="flex-1 px-3 py-2 bg-[#031727] border border-[#053b55] rounded-md text-sm text-gray-300 hover:bg-[#032437]">
                    Copy
                  </button>
                  <button className="flex-1 px-3 py-2 bg-[#031727] border border-[#053b55] rounded-md text-sm text-gray-300 hover:bg-[#032437]">
                    Download JSON
                  </button>
                  <button className="flex-1 px-3 py-2 bg-[#031727] border border-[#053b55] rounded-md text-sm text-gray-300 hover:bg-[#032437]">
                    Download PDF
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-500">
              <HistoryIcon className="w-12 h-12 mb-4" />
              <p className="text-center">Analysis results will appear here</p>
            </div>
          )}

          {/* History */}
          {history.length > 0 && (
            <div className="border-t border-[#053b55] pt-4 mt-4">
              <h4 className="text-sm uppercase text-gray-400 mb-2 flex items-center gap-2"><HistoryIcon className="w-4 h-4" /> History</h4>
              <ul className="space-y-2 max-h-48 overflow-auto pr-2">
                {history.map((item) => (
                  <li key={item.id} className="flex justify-between items-start gap-4 p-2 bg-[#031727] rounded-md border border-[#053b55] text-sm">
                    <div className="flex-1">
                      <p className="font-semibold text-[#06e5cf]">{item.input || "(untitled)"}</p>
                      <p className="text-gray-400">{item.mode.toUpperCase()} • {item.timestamp}</p>
                    </div>
                    <p className="text-right text-gray-400 flex-shrink-0 ml-2">{(item.result.confidence * 100).toFixed(0)}%</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}